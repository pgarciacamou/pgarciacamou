This Docker configuration allows to run nginx for this app alone without having
to run a global nginx configuration.

Make sure `127.0.0.1 localhost localhost.paypal.com` is in your `/etc/hosts`
file.

To start, run: `docker-compose up` inside `docker-conf/` directory. To stop,
run: `docker-compose down` inside `docker-conf/` directory. Then you can run the
app with `npm run dev` and navigate into `https://localhost.paypal.com`.

If you are encountering issues, restart the docker image from within the Docker
Dashboard.

To reload the nginx server inside your docker container without restarting
docker:\
`docker exec -it nginx-server nginx -s reload`

For more info, see:
https://engineering.paypalcorp.com/confluence/pages/viewpage.action?spaceKey=P2PConsumer\&title=Steps+to+run+multiple+node+apps+on+the+same+machine

### Troubleshooting

**ERROR**:
`"Your Connection is not private" => "You cannot visit “site” right now because the website uses HSTS."`
\
**SOLUTION**: Open up a new Chrome browser window or tab and navigate to the address
chrome://net-internals/#hsts and type the URL you are trying to access in the field
at the bottom, “Delete Domain Security Policies” and press the Delete button \
**CONTEXT**: The HTTP Strict-Transport-Security response header (HSTS) lets a
web site tell browsers that it should only be accessed using HTTPS, instead of
using HTTP, therefore, preventing access. You are probably receiving this error
because you had accessed this URL previously with a valid secure SSL over HTTPS
and after rebuilding your nginx setup it didn’t have a valid certificate, and
therefore the browser prevented access to this URL. \
**LINK**: https://virtuallywired.io/2020/01/02/fix-error-you-cannot-visit-site-right-now-because-the-website-uses-hsts/#:~:text=Fortunately%2C%20the%20fix%20is%20simple,to%20access%20that%20URL%20again.
